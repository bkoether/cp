<div id="thickbox_referral" style="margin-left: 10px">

<img src="http://vitamindaily.com/themes/DailyDose/images/referral_header.gif" alt="Hello Darling!" style="margin-top: 10px;"/>

<p style="color:#1A1A1A; font-family:georgia,times,serif; font-size:14px; line-height:20px; margin-bottom:15px; padding:0;">
Our website is growing so fast, we’ve moved to vitamindaily.com (we like to think of it as going from a studio apartment to the  penthouse). We've got two new editions, Montréal Français, and most recently: Calgary!
</p>

<p style="color:#1A1A1A; font-family:georgia,times,serif; font-size:14px; line-height:20px; margin-bottom:25px; padding:0;">
Although things may look a tad different, we're still the same inside.  We hope you'll tell us what you think in the forum ...
</p>

<p style="text-align: center; font-style: italic; color:#777; font-family:georgia,times,serif; font-size:13px; line-height:20px; margin-bottom:15px; padding:0;">
Vitamin Daily &ndash; just what the style doctor ordered.
</p>

</div>