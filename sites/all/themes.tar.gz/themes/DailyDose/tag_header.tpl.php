<?php
  $city = vitamin_city_current_city();
?>
