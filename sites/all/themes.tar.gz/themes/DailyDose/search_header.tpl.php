<div>
    Returned <?php print $num ?> results.
</div>