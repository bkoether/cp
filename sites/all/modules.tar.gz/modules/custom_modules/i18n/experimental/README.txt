These are experimental modules for i18n package.

Experimental means EXPERIMENTAL so these modules are still under development and may break stuff, 
or may not be here for future stable releases.

WARNING: Don't use them for production sites.

