README.txt
==========

********************************************************************
  These are additional modules for i18n package
********************************************************************

These modules depend on i18n.module and provide some additional features

i18nmenu.module
---------------
Translates menu items.
Runs all admin editable menu item names through localization.

i18ntaxonomy.module
------------------
Translates taxonomy terms running them through localization.
Can be enabled/disabled per vocabulary.
Provides some views support.

i18nfilter module [Not yet updated for 4.7]
----------------------------------
Provides a filter for language switching in text.
Contributed by Thomas Mandys

Jose A. Reyero, drupal at reyero dot net, http://www.reyero.net
