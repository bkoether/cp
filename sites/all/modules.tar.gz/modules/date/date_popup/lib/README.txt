Drupal date_popup.module README.txt
==============================================================================

Javascript popup calendar and timeentry using the jquery-calendar library,

==================================================================================
Contents
==================================================================================

If empty, this 'lib' folder should be filled with the following files, downloaded from
the jquery plugins page:

Download the following file from the jquery UI home page 
 at http://ui.jquery.com/
- ui.calendar.js

Download the following file from the jquery-timeentry home page
  at http://home.iprimus.com.au/kbwood/jquery/timeEntry.html
- jquery.timeentry.pack.js
