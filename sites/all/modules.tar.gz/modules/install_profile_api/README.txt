# $Id: README.txt,v 1.1 2007/03/31 07:35:46 borismann Exp $

Author: Boris Mann, http://www.bryght.com
Co Maintainers:
  Your Name Here!

This is the start of helper functions for people creating install profiles.

== Instructions ==

1. Copy crud.inc to your profiles directory (optionally, anywhere in your drupal root)
2. Use a line at the top of your .profile file to include it:
    include_once('profiles/crud.inc');

== Discussion ==

 * First announcement: http://groups.drupal.org/node/3179
 * "Distributions" Group: http://groups.drupal.org/distributions
 * Support, feature requests, etc.: http://drupal.org/project/issues/install_profile_api

