imagefield provides a image field type to cck.


Installing Imagefield.module:
  Download the imagefield release for your version.
  Untar it in the Drupal modules directory.

Activate the module through drupals administrative interface.
