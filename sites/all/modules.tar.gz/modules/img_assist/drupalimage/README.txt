$Id: README.txt,v 1.1.4.2 2007/09/21 01:37:57 sun Exp $

drupalimage plugin for TinyMCE
------------------------------

This plugin integrates the Drupal img_assist module with TinyMCE allowing
you to upload, browse and insert images into your post. Please read the
img_assist documentation for details.


Original plugin written by TinyMCE.module developers
Completely rewritten for Drupal 4.7 by BenShell (based on the TinyMCE Flash
plugin).

