tinyMCE.init({
		mode : "exact",
		theme : "advanced",
		elements : "edit-body",
		relative_urls : false,
		theme_advanced_toolbar_location : "top",
		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,separator,undo,redo,separator,cleanup,separator,bullist,numlist",
		theme_advanced_buttons2 : "",
		theme_advanced_buttons3 : ""
	});
